<!DOCTYPE html>
<html>
<head>
	<title>Mentee registration</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
	<div class="container"> 
	<?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div><br />
      <?php endif; ?>
      <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
          <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
      <?php endif; ?>
	<form action=<?php echo e(url('user')); ?> method="POST">
		<table>
			<input type="text" name="_token" value=<?php echo e(csrf_token()); ?>>
			<tr>
				<td><label>Full Name : </label></td>
				<td><input type="text" name="name"></td>
			</tr>
			<tr>
				<td><label>Phone : </label></td>
				<td><input type="text" name="phone"></td>
			</tr>
			<tr>
				<td><label>Password : </label></td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td><label>Confirm Password : </label></td>
				<td><input type="password" name="confirmPassword"></td>
			</tr>
			<tr>
				<td><label>Organization : </label></td>
				<td><input type="text" name="organization"></td>
			</tr>
			<tr>
				<td><label>Gender : </label></td>
				<td><input type="radio" name="gender" value="1">Male
					<input type="radio" name="gender" value="0">Female</td>
			</tr>
			<tr>
				<td><input type="submit" name="btnSubmit" value="Register"></td>
			</tr>
		</table>
	</form>
</div>
</body>
</html>