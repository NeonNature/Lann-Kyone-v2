<!DOCTYPE html>
<html>
<head>
	<title>Mentee Login</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
	<?php if(\Session::has('errors')): ?>
      <div class="alert alert-danger">
         <p><?php echo e(\Session::get('errors')); ?></p>
      </div><br />
      <?php endif; ?>

     <?php if(\Session::has('status')): ?>
      <div class="alert alert-success">
         <p><?php echo e(\Session::get('status')); ?></p>
      </div><br />
      <?php endif; ?>

		<form action=<?php echo e(url('user/login')); ?> method="POST">
			<table>
				<?php echo e(csrf_field()); ?>

				<tr>
					<td><label>Phone: </label></td>
					<td><input type="text" name="phone"></td>
				</tr>
				<tr>
					<td><label>Password: </label></td>
					<td><input type="password" name="password"></td>
				</tr>
				<tr>
					<td><input type="submit" name="btnSubmit" value="Login"></td>
				</tr>
			</table>
		</form>
	</div>
</body>
</html>